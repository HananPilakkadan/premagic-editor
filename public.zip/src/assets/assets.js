import premagic_icon from "./images/premagic-icon.svg";
import premagic_logo from "./images/white_logo.webp";

export const Assets = {
  premagic_icon,
  premagic_logo,
};
