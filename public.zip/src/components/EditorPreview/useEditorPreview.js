import { useDispatch, useSelector } from "react-redux";
import {
  fetchImage,
  goToRecent,
  handleRecentImageFlag,
  recentImageHandler,
  resetControls,
  takeFromRecent,
} from "../../store/slices/editingSlice";
import { useEffect } from "react";
import { toast } from "sonner";

export const useEditorPreview = () => {
  const dispatch = useDispatch();
  const { status, newImageData, recentImages, editorControls } = useSelector(
    (state) => state.editor
  );

  const loadNewImage = () => {
    dispatch(resetControls());
    dispatch(handleRecentImageFlag());

    dispatch(fetchImage())
      .then((result) => {
        if (result?.error && result?.payload) {
          toast.error("The API limit has been reached!");
        }
      })
      .catch((error) => {
        console.log(error, "error");
      });
    if (newImageData) {
      const updatedImageData = { ...newImageData };
      for (const [_, value] of Object.entries(editorControls)) {
        updatedImageData[value?.id] = value;
      }
      dispatch(recentImageHandler(updatedImageData));
    }
  };
  const handleGoToRecent = (image) => {
    dispatch(takeFromRecent(image));
    dispatch(recentImageHandler());
  };

  return { status, loadNewImage, newImageData, recentImages, handleGoToRecent };
};
